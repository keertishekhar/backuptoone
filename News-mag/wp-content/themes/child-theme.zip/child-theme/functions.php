<?php

/*
* Add your custom functions here or copy original functions and overwrite them here :)
*/