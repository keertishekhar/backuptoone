<?php


require get_template_directory() . '/inc/customizer/customizer-tabs/tab-class.php';

require get_template_directory() . '/inc/customizer/customizer-tabs/customizer.php';