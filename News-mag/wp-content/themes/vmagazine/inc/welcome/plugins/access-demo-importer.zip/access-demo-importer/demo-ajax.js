(function ($) {

    $('#resetall').click(function () {
        var ele = $(this);
        if (ele.is(':checked')) {
            $('.pdi-import-button').attr('data-reset', 'true');
        } else {
            $('.pdi-import-button').attr('data-reset', 'false');
        }
    });

    $('.pdi-import-button').click(function () {
        $import_true = confirm('Are you sure to import dummy content? it will overwrite the existing data');
        if ($import_true == false)
            return;

        $('.pdi-import-button').attr("disabled", "disabled");

        $("html, body").animate({scrollTop: 0}, "slow");

        $('.pdi-import-message').html('<div id="loader"><div class="rect1"></div><div class="rect2"></div><div class="rect3"></div><div class="rect4"></div><div class="rect5"></div></div> Data is being imported please be patient, it may take a few moments...').removeClass('pdi-success');

        var data = {
            'action': 'pdi_install_demo',
            'demo': $(this).attr('data-install'),
            'datareset': $(this).attr('data-reset'),
        };

        // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
        $.post(ajaxurl, data, function (response) {
            $('.pdi-import-message').html('Demo has been imported Successfully.').addClass('pdi-success');
            $('.pdi-import-button').removeAttr("disabled");
        });
    });

})(jQuery);