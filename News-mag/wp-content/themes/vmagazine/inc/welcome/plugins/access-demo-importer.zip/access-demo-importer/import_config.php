<?php

/*
 * Config file with each demo data
 */

return array(
    'demo-one' => array(
        'demoName' => 'World',
        'liveURL' => 'https://demo.accesspressthemes.com/vmagazine/demo-one/',
        'demoImg' => 'demo-one.jpg',
        'xmlContentFile' => 'demo-one.xml',
        'widgetFile' => 'demo-one.wie',
        'customizerFile' => 'demo-one.dat',
        'menuArray' => array(
            'primary_menu' => 'primary menu',
            'top_menu'      =>  'Top Menus',
            'footer_menu' => 'Footer Menu'
        )
    ),
    'demo-two' => array(
        'demoName' => 'Tech',
        'liveURL' => 'https://demo.accesspressthemes.com/vmagazine/demo-two/',
        'demoImg' => 'demo-two.jpg',
        'xmlContentFile' => 'demo-two.xml',
        'widgetFile' => 'demo-two.wie',
        'customizerFile' => 'demo-two.dat',
        'menuArray' => array(
            'primary_menu' => 'primary menu',
            'top_menu'      =>  'top menu',
            'footer_menu' => 'Footer Menu'   
        )
    ),
     'demo-three' => array(
        'demoName' => 'Travel',
        'liveURL' => 'https://demo.accesspressthemes.com/vmagazine/demo-three/',
        'demoImg' => 'demo-three.jpg',
        'xmlContentFile' => 'demo-three.xml',
        'widgetFile' => 'demo-three.wie',
        'customizerFile' => 'demo-three.dat',
        'menuArray' => array(
            'primary_menu' => 'primary menu',
            'footer_menu' => 'Footer Menu'
        )
    ),
    'demo-four' => array(
        'demoName'          => 'Sports',
        'liveURL'           => 'https://demo.accesspressthemes.com/vmagazine/demo-four/',
        'demoImg'           => 'demo-four.jpg',
        'xmlContentFile'    => 'demo-four.xml',
        'widgetFile'        => 'demo-four.wie',
        'customizerFile'    => 'demo-four.dat',
        'menuArray'     => array(
            'primary_menu'  => 'Main Menu',
            'footer_menu'   => 'Footer Menu',
            'top_menu'      =>  'Footer Menu'
        )
    ),

   'demo-fitness' => array(
    'demoName'          => 'Fitness',
    'liveURL'           => 'https://demo.accesspressthemes.com/vmagazine/demo-five/',
    'demoImg'           => 'demo-fitness.jpg',
    'xmlContentFile'    => 'demo-fitness.xml',
    'widgetFile'        => 'demo-fitness.wie',
    'customizerFile'    => 'demo-fitness.dat',
    'menuArray'     => array(
        'primary_menu'  => 'primary menu',
        'footer_menu'   => 'Footer Menu',
        'top_menu'      =>  'top menu'
    )
),


    'demo-food' => array(
    'demoName'          => 'Food',
    'liveURL'           => 'https://demo.accesspressthemes.com/vmagazine/demo-six/',
    'demoImg'           => 'demo-food.jpg',
    'xmlContentFile'    => 'demo-food.xml',
    'widgetFile'        => 'demo-food.wie',
    'customizerFile'    => 'demo-food.dat',
    'menuArray'     => array(
        'primary_menu'  => 'Main Menu',
        'footer_menu'   => 'Footer Menu',
        'top_menu'      =>  'top menu'
    )
),

    'demo-fashion' => array(
    'demoName'          => 'Fashion',
    'liveURL'           => 'https://demo.accesspressthemes.com/vmagazine/demo-seven/',
    'demoImg'           => 'demo-fashion.jpg',
    'xmlContentFile'    => 'demo-fashion.xml',
    'widgetFile'        => 'demo-fashion.wie',
    'customizerFile'    => 'demo-fashion.dat',
    'menuArray'     => array(
        'primary_menu'  => 'Fashion Menu',
        'footer_menu'   => 'Footer Menu',
        'top_menu'      =>  'top menu'
    )
),

    'demo-game' => array(
    'demoName'          => 'Game Dark Version',
    'liveURL'           => 'https://demo.accesspressthemes.com/vmagazine/demo-nine/',
    'demoImg'           => 'demo-game.jpg',
    'xmlContentFile'    => 'demo-game.xml',
    'widgetFile'        => 'demo-game.wie',
    'customizerFile'    => 'demo-game.dat',
    'menuArray'     => array(
        'primary_menu'  => 'primary menu',
        'footer_menu'   => 'Footer Menu',
        'top_menu'      =>  'top menu'
    )
),

    'demo-gaming' => array(
    'demoName'          => 'Game Light Version',
    'liveURL'           => 'https://demo.accesspressthemes.com/vmagazine/demo-ten/',
    'demoImg'           => 'demo-gaming.jpg',
    'xmlContentFile'    => 'demo-gaming.xml',
    'widgetFile'        => 'demo-gaming.wie',
    'customizerFile'    => 'demo-gaming.dat',
    'menuArray'     => array(
        'primary_menu'  => 'primary menu',
        'footer_menu'   => 'Footer Menu',
        'top_menu'      =>  'top menu'
    )
),
    
    

    
   
);
